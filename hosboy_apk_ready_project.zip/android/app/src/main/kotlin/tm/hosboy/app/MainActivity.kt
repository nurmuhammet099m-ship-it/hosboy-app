package tm.hosboy.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
